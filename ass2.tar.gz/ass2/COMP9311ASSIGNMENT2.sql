-- COMP9311 ASSIGNMENT 2
-- Author: Yunqiu Xu
-- ID: z5096489

-------------------------------------------------
-- ASX database
-- may need SQL/PLpgSQL functions
-- iff SQL query is also OK
-- all queries should be SQL views using given attribute names
	-- CREATE OR REPLACE VIEW xxx AS
-- default ascending order except it's mentioned

-- disregard the first trading day 
	-- when counting the total number
-- e 1: average price of a stock 5 trading days
	-- (A+B+C+D+E)/5
-- e 2: average gain in percentage
	-- (B+C+D+E)/4

-- Queries are worth equal marks. 40 total
-- 4 (out of 40) marks will be allocated for 
-- documentation and coding style (e.g., comments). 
-------------------------------------------------

-- PASS
-- 1. List all the company names (and countries) 
	-- that are incorporated outside Australia.

CREATE OR REPLACE VIEW Q1(Name, Country) AS
	SELECT Name,Country FROM Company 
	WHERE Country !~ 'Australia';
-- 10 companies

-------------------------------------------------

-- PASS
-- 2. List all the company codes 
	--that have more than five executive members on record 
	--(i.e., at least six).

-- Create a template view GetCount using "WITH" to
	-- get the count of executives from the same company
	-- then group them by different companies
CREATE OR REPLACE VIEW Q2(Code) AS
	SELECT Code	FROM Executive
	GROUP BY Code
	HAVING COUNT(Person)>5;

-------------------------------------------------

-- PASS
-- 3. List all the company names 
	-- that are in the sector of "Technology"
CREATE OR REPLACE VIEW Q3(Name) AS
	SELECT Company.name FROM Company,Category
	WHERE Category.Code=Company.Code
	AND Category.Sector ~ 'Technology';

-------------------------------------------------

-- PASS
-- 4. Find the number of Industries in each Sector
CREATE OR REPLACE VIEW Q4(Sector,Number) AS
	SELECT Sector,COUNT(Industry) FROM Category
	GROUP BY Sector;
-- 8 kinds of sectors

-------------------------------------------------

-- PASS
-- 5. Find all the executives (i.e., their names) 
	-- that are affiliated with companies 
	-- in the sector of "Technology". 
--  If an executive is affiliated with more than one company, 
	-- he/she is counted if one of these companies 
	-- is in the sector of "Technology".

-- Test if there are executives in more than one company
	-- We can find 'CHC' and 'CQR' are in this condition
	-- However these 2 company are in the sector of
	-- 'Financial'
-- SELECT E1.Code,E1.Person FROM Executive E1,Executive E2
	-- WHERE E1.Person=E2.Person
	-- AND E1.Code != E2.Code;


CREATE OR REPLACE VIEW Q5(Name) AS
	SELECT DISTINCT E.Person AS Name FROM Executive E 
	JOIN Category C
	ON (E.Code=C.Code AND C.Sector ~ 'Technology'); 

-------------------------------------------------

-- PASS
-- 6. List all the company names 
	-- in the sector of "Services" 
	-- that are located in Australia 
	-- with the first digit of their zip code being 2.

CREATE OR REPLACE VIEW Q6(Name) AS
	SELECT Co.Name FROM Company Co JOIN Category Ca 
	ON(Co.Code=Ca.Code
		AND Ca.Sector ~ 'Services'
		AND Co.Country ~ 'Australia'
		AND Co.Zip LIKE '2%'
	)
;

-------------------------------------------------


-- 7. Create a database view of the ASX table 
	-- that contains previous Price, 
		-- Price change (in amount, can be negative) 
		-- and Price gain (in percentage, can be negative).
	-- (Note that the first trading day 
	-- should be excluded in your result.)  

-- For example, if the PrevPrice is 1.00, Price is 0.85; 
	-- then Change is -0.15 and Gain is -15.00
 	-- (in percentage but you do not need to print out 
 	-- the percentage sign).

-- Create a new function PrevPrice(Code,"Date")
	-- Input the code of company and current date
	-- Output the price of this company at last date
	-- note that 'last date' are not always 'yesterday'
CREATE OR REPLACE FUNCTION PrevPrice(Char(3),Date)
RETURNS Numeric
AS $$
	SELECT Price FROM Asx
	WHERE Code=$1 AND
	"Date"<$2
	ORDER BY "Date" DESC
	LIMIT 1
$$ language SQL;

-- Create a new function FirstDay(Code)
	-- Input the code of company
	-- Output the first trading day
CREATE OR REPLACE FUNCTION FirstDay(Char(3))
RETURNS Date
AS $$
	SELECT "Date" FROM Asx
	WHERE Code=$1
	ORDER BY "Date"
	LIMIT 1
$$ language SQL;

CREATE OR REPLACE VIEW Q7("Date", Code, Volume, 
 	PrevPrice, Price, Change, Gain) AS
	SELECT "Date", Code, Volume, 
 	PrevPrice(Code,"Date"),Price,
 	(Price-PrevPrice(Code,"Date")) AS Change,
 	(Price-PrevPrice(Code,"Date"))*100/PrevPrice(Code,"Date") AS Gain
 	FROM Asx
 	WHERE "Date">FirstDay(Code);

-------------------------------------------------


-- 8. Find the most active trading stock 
	-- (the one with the maximum trading volume; 
	-- if more than one, output all of them) 
	-- on every trading day. 
	-- Order your output by "Date" and then by Code.


-- Using "WITH"
	-- template view CDV(CollectDateVolume): everyday's max valume
	-- template view FR(FinalResult): output the final result

CREATE OR REPLACE VIEW Q8("Date", Code, Volume) AS
	WITH 
	CDV AS (SELECT "Date",MAX(Volume) FROM Asx GROUP BY "Date"),
	FR AS (SELECT "Date", Code, Volume FROM Asx)
	SELECT FR."Date",FR.Code,FR.Volume FROM FR JOIN CDV ON(
		FR."Date"=CDV."Date"
		AND FR.Volume=CDV.MAX
		)
	ORDER BY FR."Date",FR.Code;

-------------------------------------------------


-- 9. Find the number of companies per Industry. 
	-- Order your result by Sector and 
	-- then by Industry.

CREATE OR REPLACE VIEW Q9(Sector, Industry, Number) AS	
	SELECT DISTINCT Sector,Industry,COUNT(Code) 
	OVER (PARTITION BY Industry)
	FROM Category
	ORDER BY Sector,Industry;

-------------------------------------------------


-- 10. List all the companies (by their Code) 
	-- that are the only one in their Industry 
	-- (i.e., no competitors).

-- Q10 is based on Q9 
	-- find those industroes with only one company 
CREATE OR REPLACE VIEW 	Q10(Code,Industry) AS
	SELECT Code,Industry FROM Category
	WHERE Industry IN (SELECT Industry FROM Q9 WHERE Number=1);

-------------------------------------------------


-- 11. List all sectors ranked by 
	-- their average ratings in descending order. 
-- AvgRating is calculated by 
	-- finding the average AvgCompanyRating 
	-- for each sector 
-- (where AvgCompanyRating is 
	-- the average rating of a company).


-- AvgCompanyRating= (sum of rating)/(number of rating)
	-- in one company
	-- Create a new function GACR(Code)
	-- return the AvgCompanyRating of given code

CREATE OR REPLACE FUNCTION GACR(Char(3))
RETURNS Numeric
AS $$
SELECT SUM(Star)*1.0/COUNT(Star)
FROM Rating WHERE Code=$1
$$ language SQL;

-- AvgRating=(sum of acr)/(number of companies)
	-- in one sector
	-- Create a new function GAR(Sector)
	-- return the AvgRating of given sector
CREATE OR REPLACE FUNCTION GAR(Char(3))
RETURNS Numeric
AS $$
SELECT SUM(GACR(Code))*1.0/COUNT(Code)
FROM Category WHERE Sector=$1
$$ language SQL;

CREATE OR REPLACE VIEW 	Q11(Sector,AvgRating) AS
	SELECT Sector, GAR(Sector)
	FROM Category
	GROUP BY Sector
	ORDER BY GAR DESC;

-------------------------------------------------


-- 12. Output the person names of the executives 
	-- that are affiliated with 
	-- more than one company.
-- A test code in Q5

CREATE OR REPLACE VIEW Q12(Name) AS
	SELECT DISTINCT E1.Person FROM Executive E1,Executive E2
	WHERE E1.Person=E2.Person
	AND E1.Code != E2.Code;

-------------------------------------------------


-- 13. Find all the companies 
	-- with a registered address in Australia, 
	-- in a Sector where there are 
	-- no overseas companies in the same Sector. 
-- i.e., they are in a Sector that 
	-- all companies there 
	-- have local Australia address.
-- sectors with oversea companies should be excluded!

-- create a template view OverSea using WITH
	-- to get all Sectors that have company not in Australia
	-- a little  more complex than Q1

CREATE OR REPLACE VIEW Q13(Code, Name, Address, Zip, Sector) AS
	WITH OverSea AS
	(SELECT DISTINCT Ca.Sector
	FROM Company Co JOIN Category Ca
	ON(Co.Code=Ca.Code
		AND Co.Country !~ 'Australia'))
	-- only 3 of 8 sectors satisfy the requirment
	SELECT Co.Code,Co.Name,Co.Address,Co.Zip,Ca.Sector
	FROM Company Co JOIN Category Ca
	ON(Co.Code=Ca.Code
		AND
	Ca.Sector NOT IN(SELECT * FROM OverSea)
	)
;

-------------------------------------------------


-- 14. Calculate stock gains based on 
	-- their prices of the first trading day 
	-- and last trading day 
-- (i.e., the oldest "Date" and 
	-- the most recent "Date" of the records 
	-- stored in the ASX table). 
-- Order your result by Gain in 
	-- descending order and 
	-- then by Code in ascending order.

-- Get BeginPrice using the function FirstDay
	-- defined in Q7
-- Create a new function LastDay(Code)
	-- Input the code of company
	-- Output the last trading day
CREATE OR REPLACE FUNCTION LastDay(Char(3))
RETURNS Date
AS $$
	SELECT "Date" FROM Asx
	WHERE Code=$1
	ORDER BY "Date" DESC
	LIMIT 1
$$ language SQL;

CREATE OR REPLACE VIEW Q14(Code,BeginPrice,EndPrice,
	Change,Gain) AS
	WITH GetBeginPrice AS
	(SELECT Code,Price AS BeginPrice 
		FROM Asx
		WHERE "Date"=FirstDay(Code)
		),
	GetLastPrice AS 
	(SELECT Code,Price AS EndPrice 
		FROM Asx
		WHERE "Date"=LastDay(Code)
		)

	SELECT DISTINCT Asx.Code, GBP.BeginPrice, GLP.EndPrice,
	(GLP.EndPrice-GBP.BeginPrice) AS Change,
	(GLP.EndPrice-GBP.BeginPrice)*100/GBP.BeginPrice AS Gain
	FROM Asx JOIN GetBeginPrice GBP
	ON (Asx.Code=GBP.Code)
	JOIN GetLastPrice GLP
	ON (Asx.Code=GLP.Code)
	ORDER BY Gain DESC,Code
;

-------------------------------------------------


-- 15. For all the trading records in the ASX table, 
	-- produce the following statistics as a database view 
	--(where Gain is measured in percentage). 
-- AvgDayGain is defined as the summation 
	-- of all the daily gains (in percentage) 
	-- then divided by the number of trading days 
-- (as noted above, the total number of days here 
	-- should exclude the first trading day).

-- create 6 functions to get the statistical data
CREATE OR REPLACE FUNCTION MinP(Char(3))
RETURNS Numeric AS
$$
SELECT MIN(Price) FROM Asx
WHERE Code=$1
$$ language SQL;

CREATE OR REPLACE FUNCTION AvgP(Char(3))
RETURNS Numeric AS
$$
SELECT AVG(Price) FROM Asx
WHERE Code=$1
$$ language SQL;

CREATE OR REPLACE FUNCTION MaxP(Char(3))
RETURNS Numeric AS
$$
SELECT MAX(Price) FROM Asx
WHERE Code=$1
$$ language SQL;

CREATE OR REPLACE FUNCTION MinG(Char(3))
RETURNS Numeric AS
$$
SELECT MIN(Gain) FROM Q7
WHERE Code=$1
$$ language SQL;

CREATE OR REPLACE FUNCTION AvgG(Char(3))
RETURNS Numeric AS
$$
SELECT AVG(Gain) FROM Q7
WHERE Code=$1
$$ language SQL;

CREATE OR REPLACE FUNCTION MaxG(Char(3))
RETURNS Numeric AS
$$
SELECT Max(Gain) FROM Q7
WHERE Code=$1
$$ language SQL;

CREATE OR REPLACE VIEW Q15(Code,MinPrice,AvgPrice,
	MaxPrice, MinDayGain, AvgDayGain, MaxDayGain) AS
	SELECT 
		Code,
		MinP(Code),
		AvgP(Code),
		MaxP(Code),
		MinG(Code),
		AvgG(Code),
		MaxG(Code)
	FROM Company;

-------------------------------------------------


-- 16. Create a trigger on the Executive table, 
	-- to check and disallow 
	-- any insert or update of a Person 
	-- in the Executive table 
	-- to be an executive of more than one company. 

-- We need to create two triggers one for insert
	-- another for update
	-- we should test if the changed record have same
	-- id in the table

-- 16.1 The first trigger: InsertExecutive
	-- trigger function: insertExecutive() 
CREATE TRIGGER InsertExecutive
AFTER INSERT ON Executive
FOR EACH ROW EXECUTE PROCEDURE insertExecutive();

CREATE OR REPLACE FUNCTION insertExecutive()
RETURNS TRIGGER
AS $$
DECLARE 
	E Executive;
BEGIN
	-- Check whether the new person has been appeared
	SELECT * INTO E FROM Executive WHERE(Person=NEW.Person);
	IF(E IS NOT NULL) THEN
		NULL;
		-- 2 cases: 
			-- this person has been the executive of another company;
			-- this person has been the executive of this company
		-- both of these 2 cases should be avoided: update nothing
		-- another choice is RAISE EXCEPTION	
	END IF;
	RETURN NEW;
END;
$$ language plpgsql;

-- 16.2 The second trigger: UpdateExecutive
	-- trigger function: updateExecutive()
-- there are 2 kinds of updates
	-- change the company of particular person
	-- or change this person to another person
		-- another person should be a new person
		-- otherwise it leads to error
CREATE TRIGGER UpdateExecutive
AFTER UPDATE ON Executive
FOR EACH ROW EXECUTE PROCEDURE updateExecutive();

CREATE OR REPLACE FUNCTION updateExecutive()
RETURNS TRIGGER
AS $$
DECLARE 
	ENew Executive;
	-- EOld Executive
BEGIN
	SELECT * INTO ENew FROM Executive WHERE(Person=NEW.Person);
	-- Case 1: change the company while name is not change
	IF(NEW.PERSON==OLD.PERSON) THEN
		IF(NEW.CODE==OLD.CODE) THEN
			NULL; -- no changes
		END IF;
		-- if not the code company changes
			-- this doesn't matter
			-- cos in the old table
			-- no person will in 2 companies
	-- Case 2: change this executive with another person
	ELSE
		-- check if this new person is unique in the old table
		-- it doesn't matter whether the company changes in this case
		IF(ENew IS NOT NULL) THEN
			NULL;
		END IF;
	END IF;
	RETURN NEW;
END;
$$ language plpgsql;

-------------------------------------------------

-- 17. Create a trigger to increase the stock's rating 
	-- (as Star's) to 5 
	-- when the stock has made a maximum daily price gain 
	-- (when compared with the price on the previous trading day)
	-- in percentage within its sector.
-- For example, for a given day and a given sector, 
	-- if Stock A has the maximum price gain in the sector, 
	-- its rating should then be updated to 5
-- If it happens to have more than one stock 
	-- with the same maximum price gain,
 	-- update all these stocks' ratings to 5.
-- Otherwise, decrease the stock's rating to 1 
	-- when the stock has performed the worst 
	-- in the sector in terms of daily percentage price gain.
-- If there are more than one record of rating 
	-- for a given stock that need to be updated, 
	-- update (not insert) all these records. 


-- Create a new function : GetAllRecords(t Char(3),d Date)
	-- When a new record is inserted into asx,
	-- find all companies with same date and sector,
	-- return the code and gain of company.
-- Other functions: PrevPrice, FirstDate defined in Q7
CREATE TYPE records AS (Code char(3), Gain Numeric);
CREATE OR REPLACE FUNCTION GetAllRecords(t Char(3),d Date)
RETURNS SETOF records
AS $$
DECLARE
	V records;
BEGIN
	FOR V IN SELECT Asx.Code,(Asx.Price-PrevPrice(Asx.Code,Asx."Date"))*100/PrevPrice(Asx.Code,Asx."Date") 
		FROM Asx JOIN Category
		ON(Asx."Date"=d
			AND Asx.Code=Category.Code
			AND Category.Sector=(SELECT Sector FROM Category WHERE Code=t))
	LOOP
		RETURN NEXT V;
	END LOOP;
	RETURN;
END;
$$ language plpgsql;

-- Create the trigger:
CREATE TRIGGER ChangeRating
AFTER INSERT ON Asx
FOR EACH ROW EXECUTE PROCEDURE changeRating();

-- Create the trigger function:
CREATE OR REPLACE FUNCTION changeRating()
RETURNS TRIGGER 
AS $$
DECLARE
	curr_max Char(3);
	curr_min Char(3);
BEGIN
	-- if the company is inserted for the first time, do nothing
	IF (NEW."Date"=FirstDay(NEW.Code)) THEN
		RETURN NEW;

	-- else: calculate the gain
	ELSE
		-- update the company with the min gain
		FOR curr_min IN SELECT Code FROM GetAllRecords(NEW.Code,NEW."Date") 
			WHERE Gain=(SELECT MIN(Gain) FROM GetAllRecords(NEW.Code,NEW."Date"))
		LOOP
			UPDATE Category
			SET Star=1
			WHERE Code=curr_min;
		END LOOP;
		-- update the company with the max gain
		FOR curr_max IN SELECT Code FROM GetAllRecords(NEW.Code,NEW."Date") 
			WHERE Gain=(SELECT MAX(Gain) FROM GetAllRecords(NEW.Code,NEW."Date"))
		LOOP
			UPDATE Category
			SET Star=5
			WHERE Code=curr_max;
		END LOOP;
	END IF;
	RETURN NEW;
END;
$$ language plpgsql;


-------------------------------------------------


-- 18. Stock price and trading volume data are usually 
	-- incoming data and seldom involve updating existing data. 
	-- However, updates are allowed in order to correct data errors. 
	-- All such updates (instead of data insertion) are logged and stored 
	-- in the ASXLog table. 
-- Create a trigger to log any updates on Price and/or Voume 
	-- in the ASX table and log these updates 
	-- (only for update, not inserts) into the ASXLog table. 
-- Here we assume that Date and Code cannot be corrected 
	-- and will be the same as their original, old values. 
-- Timestamp is the date and time that the correction takes place. 
	-- Note that it is also possible that 
	-- a record is corrected more than once, 
	-- i.e., same Date and Code but different Timestamp.

CREATE TRIGGER LogUpdates
AFTER UPDATE ON Asx
FOR EACH ROW EXECUTE PROCEDURE logUpdates();

CREATE OR REPLACE FUNCTION logUpdates()
RETURNS TRIGGER 
AS $$
BEGIN
	INSERT INTO Asxlog
	VALUES(current_timestamp,OLD."Date",OLD.Code,OLD.Volume,OLD.Price);
	RETURN NEW;
END;
$$ language plpgsql;
